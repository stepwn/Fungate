/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-i18n/
 */
import { __ } from '@wordpress/i18n';

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from '@wordpress/block-editor';

/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';


import { InspectorControls, InnerBlocks } from '@wordpress/block-editor';
import { PanelBody, TextControl, SelectControl } from '@wordpress/components';

export default function Edit({ attributes, setAttributes }) {
    return (
        <div {...useBlockProps()}>
            <InspectorControls>
                <PanelBody title={__('Settings', 'fungate-block')}>
                    <SelectControl
                        label={__('Chain', 'fungate-block')}
                        value={attributes.chain}
                        options={[
                            { label: 'Ethereum', value: 'ethereum' },
                            { label: 'Polygon', value: 'polygon' },
                            // Add other chains here
                        ]}
                        onChange={(chain) => setAttributes({ chain })}
                    />
                    <TextControl
                        label={__('Minter', 'fungate-block')}
                        value={attributes.minter}
                        onChange={(minter) => setAttributes({ minter })}
                    />
                    <TextControl
                        label={__('Contract', 'fungate-block')}
                        value={attributes.contract}
                        onChange={(contract) => setAttributes({ contract })}
                    />
                    <TextControl
                        label={__('NFT', 'fungate-block')}
                        value={attributes.nft}
                        onChange={(nft) => setAttributes({ nft })}
                    />
                    <TextControl
                        label={__('Schedule', 'fungate-block')}
                        value={attributes.schedule}
                        onChange={(schedule) => setAttributes({ schedule })}
                    />
                </PanelBody>
            </InspectorControls>
            <InnerBlocks />
        </div>
    );
}
