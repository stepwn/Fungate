/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from '@wordpress/block-editor';

/**
 * The save function defines the way in which the different attributes should
 * be combined into the final markup, which is then serialized by the block
 * editor into `post_content`.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#save
 *
 * @return {Element} Element to render.
 */
// Utility function to determine the file type

const getFileType = (fileName) => {
    if (!fileName) return 'unknown'; // Return 'unknown' or a default type if fileName is undefined

    const extension = fileName.split('.').pop().toLowerCase();
    if (['mp3', 'wav', 'ogg', 'm4a'].includes(extension)) {
        return 'audio';
    } else if (['mp4', 'webm', 'ogv'].includes(extension)) {
        return 'video';
    } else {
        return 'image';
    }
};

export default function save({ attributes }) {
    const { src, contract, minter, nft, schedule } = attributes;
    const hasGateAttributes = contract || minter || nft || schedule;

    // Check if src is defined before determining the file type
    const fileType = src ? getFileType(src) : 'unknown'; // Use 'unknown' or a default type if src is undefined
    const fungateMediaShortcode = src ? `[fungate_media src="${src}" type="${fileType}"]` : '';

    if (hasGateAttributes) {
        return src ? `[fungate contract="${contract}" minter="${minter}" nft="${nft}" schedule="${schedule}"]${fungateMediaShortcode}[/fungate]` : '';
    }

    return fungateMediaShortcode;
}
