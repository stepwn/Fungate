/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-i18n/
 */
import { __ } from '@wordpress/i18n';

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from '@wordpress/block-editor';

/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#edit
 *
 * @return {Element} Element to render.
 */
import { useState, useEffect } from '@wordpress/element';
import { InspectorControls } from '@wordpress/block-editor';
import { Button, TextControl, PanelBody, PanelRow, CheckboxControl } from '@wordpress/components';
import { get } from '@wordpress/url';

// Utility function to determine the file type
const getFileType = (fileName) => {
    const extension = fileName.split('.').pop();
    if (['png', 'jpg', 'jpeg', 'gif', 'bmp', 'svg'].includes(extension)) {
        return 'image';
    } else if (['mp4', 'webm', 'ogv'].includes(extension)) {
        return 'video';
    } else if (['mp3', 'wav', 'ogg'].includes(extension)) {
        return 'audio';
    }
    return 'other';
};

const CustomMediaPicker = ({ onFileSelect, selectedFile }) => {
    const [files, setFiles] = useState([]);

    useEffect(() => {
        fetch('/wp-json/fungate/v1/list-media', {
            method: 'GET',
            headers: {
                'X-WP-Nonce': wpApiSettings.nonce
            }
        })
        .then(response => response.json())
        .then(data => {
            const filesArray = Object.values(data);
            setFiles(filesArray);
        })
        .catch(error => console.error('Error:', error));
    }, []);

    return (
        <select 
            value={selectedFile} 
            onChange={(e) => onFileSelect(e.target.value)}
            style={{ width: '100%', padding: '8px', marginBottom: '20px' }}
        >
            <option value="">Select a file</option>
            {files.map(file => (
                <option key={file} value={file}>
                    {file.split('/').pop()} {/* Displaying just the file name */}
                </option>
            ))}
        </select>
    );
};


export default function Edit({ attributes, setAttributes }) {
    const { src, contract, minter, nft, schedule, showDownloadButton } = attributes;

    // File selection handler remains the same
    const handleFileSelect = (fileName) => {
		setAttributes({ src: fileName });
	};

	const handleFileUpload = (fileEvent) => {
		let file;
		if (fileEvent instanceof Event) {
			// Handle event from input type=file
			file = fileEvent.target.files[0];
		} else if (fileEvent instanceof File) {
			// Handle file directly passed to the function
			file = fileEvent;
		}
	
		if (!file) {
			console.error('No file provided');
			return;
		}
	
		const formData = new FormData();
		formData.append('file', file);
	
		fetch('/wp-json/fungate/v1/upload-media', {
			method: 'POST',
			headers: {
				'X-WP-Nonce': wpApiSettings.nonce
			},
			body: formData
		})
		.then(response => response.json())
		.then(data => {
			console.log(data.message); // Or handle the response appropriately
		})
		.catch(error => console.error('Error:', error));
	};
	

    return (
        <div {...useBlockProps()}>
            {/* Block Content: File Picker */}
			<div>
            <input type="file" id="fileInput" onChange={(e) => handleFileUpload(e)} />
    <button onClick={() => {
        const fileInput = document.getElementById('fileInput');
        if (fileInput && fileInput.files.length > 0) {
            handleFileUpload(fileInput.files[0]);
        }
    }}>Upload File</button>
        </div>
		<CustomMediaPicker onFileSelect={handleFileSelect} selectedFile={src} />

			{/* Display the selected file name */}
            {src && <p>Selected File: {src.split('/').pop()}</p>}

            {/* Sidebar Controls */}
            <InspectorControls>
                <PanelBody title="Settings">
                    <PanelRow>
                        <TextControl
                            label="Contract"
                            value={contract}
                            onChange={(value) => setAttributes({ contract: value })}
                        />
                    </PanelRow>
                    <PanelRow>
                        <TextControl
                            label="Minter"
                            value={minter}
                            onChange={(value) => setAttributes({ minter: value })}
                        />
                    </PanelRow>
                    <PanelRow>
                        <TextControl
                            label="NFT"
                            value={nft}
                            onChange={(value) => setAttributes({ nft: value })}
                        />
                    </PanelRow>
                    <PanelRow>
                        <TextControl
                            label="Schedule"
                            value={schedule}
                            onChange={(value) => setAttributes({ schedule: value })}
                        />
                    </PanelRow>
                    <PanelRow>
                        <CheckboxControl
                            label="Show Download Button"
                            checked={showDownloadButton}
                            onChange={(value) => setAttributes({ showDownloadButton: value })}
                        />
                    </PanelRow>
                </PanelBody>
            </InspectorControls>
        </div>
    );
}
