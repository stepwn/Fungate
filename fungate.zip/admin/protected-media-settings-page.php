<?php
/**
 * Displays a media management page in the admin area.
 */
function fungate_media_page() {
    fungate_admin_page_render();
    if (!current_user_can('upload_files')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    // Display media upload form
    echo '<div class="fungate-wrap">';
    echo '<h1>Fungate Media</h1>';
    echo '<p>Welcome to the Fungate Media dashboard. Here, you can easily upload and manage your media files.</p>';
    
    echo '<h2>Upload Media</h2>';
    echo '<form id="fungate-media-upload-form" enctype="multipart/form-data">';
    echo '<input type="file" name="file">';
    echo '<input type="submit" value="Upload" class="button button-primary">';
    echo '</form>';

    echo '<h2>Uploaded Files</h2>';
    
    $protected_folder_path = plugin_dir_path(dirname(__FILE__)) . 'protected-folder/';
    $files = scandir($protected_folder_path);
    
    if (!empty($files)) {
        echo '<ul>';
        foreach ($files as $file) {
            if ($file != '.' && $file != '..' && $file != '.htaccess') {
                $file_url = plugin_dir_url(dirname(__FILE__)) . 'protected-folder/' . urlencode($file);
                echo '<li>' . $file . ' - <a href="' . $file_url . '" target="_blank">View</a> - <button class="delete-button" data-file="' . urlencode($file) . '">Delete</button></li>';
            }
        }
        echo '</ul>';
    } else {
        echo '<p>No files uploaded.</p>';
    }
    
    echo '</div>'; // End of wrap div

    // JavaScript for handling file upload and deletion
    echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const uploadForm = document.querySelector("#fungate-media-upload-form");

            uploadForm.addEventListener("submit", function(event) {
                event.preventDefault();
                const formData = new FormData(uploadForm);
                
                fetch("/wp-json/fungate/v1/upload-media", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    location.reload();
                })
                .catch(error => alert("Error: " + error));

            });

            document.querySelectorAll(".delete-button").forEach(button => {
                button.addEventListener("click", function() {
                    const file = button.getAttribute("data-file");
                    if(confirm("Are you sure you want to delete this file?")) {
                        fetch("/wp-json/fungate/v1/delete-media", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({ file: file })
                        })
                        .then(response => response.json())
                        .then(data => {
                            alert(data.message);
                            location.reload();
                        })
                        .catch(error => alert("Error: " + error));
                    }
                });
            });
        });
    </script>';
}


add_action( 'rest_api_init', function () {
    register_rest_route( 'fungate/v1', '/upload-media', array(
        'methods' => 'POST',
        'callback' => 'fungate_handle_media_upload',
        'permission_callback' => function () {
            return current_user_can( 'upload_files' );
        },
    ));

    register_rest_route( 'fungate/v1', '/delete-media', array(
        'methods' => 'POST',
        'callback' => 'fungate_handle_media_delete',
        'permission_callback' => function () {
            return current_user_can( 'upload_files' );
        },
    ));
});

function fungate_handle_media_upload( WP_REST_Request $request ) {
    $protected_folder_path = plugin_dir_path(dirname(__FILE__)) . 'protected-folder/';
    if (!file_exists($protected_folder_path)) {
        mkdir($protected_folder_path, 0755, true);
    }

    $file = $request->get_file_params()['file'];
    $file_path = $protected_folder_path . $file['name'];

    if (move_uploaded_file($file['tmp_name'], $file_path)) {
        return new WP_REST_Response('File uploaded successfully', 200);
    } else {
        return new WP_REST_Response('Error uploading file', 500);
    }
}

function fungate_handle_media_delete( WP_REST_Request $request ) {
    $protected_folder_path = plugin_dir_path(dirname(__FILE__)) . 'protected-folder/';
    $file_name = sanitize_file_name($request['file']);
    $file_path = $protected_folder_path . $file_name;

    if (file_exists($file_path)) {
        unlink($file_path);
        return new WP_REST_Response('File deleted successfully', 200);
    } else {
        return new WP_REST_Response('File not found', 404);
    }
}
