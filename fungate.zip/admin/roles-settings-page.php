<?php

function fungate_roles_page(){
    fungate_admin_page_render();
    ?>
    <div class="fungate-wrap">
        <h1>Fungate Role Settings</h1>
        <form id="fungate_roles_form" method="post" action="">
        <?php
            // Use a unique option name for this page's settings
            $option_name = 'fungate_nft_roles_settings';
            
            if (isset($_POST['fungate_submit'])) {
                // Handle form submission and update settings
                update_option($option_name, $_POST);
                ?>
                <div class="updated"><p><strong>Settings saved.</strong></p></div>
                <?php
            }

            // Retrieve the settings
            $settings = get_option($option_name);

            // Initialize default values if settings are empty
            $settings = !empty($settings) ? $settings : array(
                'nft_roles_enabled' => 0,
                'selected_role' => '',
                'nft_roles' => array(),
            );
            
            // Display form fields
            ?>
            <table>
                <tr>
                    <th scope="row"><label for="nft_roles_enabled">Enable NFT Roles</label></th>
                    <td><input type="checkbox" id="nft_roles_enabled" name="nft_roles_enabled" value="1" <?php checked(1, $settings['nft_roles_enabled'], true); ?> /></td>
                    <td>Enable Wordpress Role Modification based on NFT ownership</td>
                </tr>
                <tr>
                    <th scope="row"><label for="default_nft_role">Default NFT Role</label></th>
                    <td>
                        <select id="default_nft_role" name="default_nft_role">
                        <?php 
                        global $wp_roles;
                        $all_roles = array_reverse($wp_roles->roles);
                        $default_nft_role = get_option('default_nft_role', '');
                        foreach ($all_roles as $role_name => $role_info): 
                        ?>
                            <option value="<?php echo strtolower($role_name); ?>" <?php selected(strtolower($role_name), strtolower($default_nft_role));?>><?php echo $role_info['name']; ?></option>
                        <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            </table>
            <hr>
            <h3>Select a role to change gating logic</h3>
            <table class="form-table">
                <tr>
                    <td>
                        <label for="selected_role">Select Role:</label>
                        <select id="selected_role" name="selected_role">
                        <option value="" default>Select Role</option>
                            <?php
                            global $wp_roles;
                            $all_roles = $wp_roles->roles;
                            foreach ($all_roles as $role_name => $role_info):
                            ?>
                                <option value="<?php echo $role_name; ?>" <?php selected($role_name, $settings['selected_role']); ?>><?php echo $role_info['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <?php
                foreach ($all_roles as $role_name => $role_info):
                ?>
                <tr class="role-row fungate-role-inputs" data-role="<?php echo $role_name; ?>" style="<?php echo ($role_name == $settings['selected_role']) ? '' : 'display: none;'; ?>">
                    <td>
                        <div>
                            <label for="nft_role_<?php echo $role_name; ?>_minter">Minter</label>
                            <input type="text" id="nft_role_<?php echo $role_name; ?>_minter" name="nft_roles[<?php echo $role_name; ?>][minter]" value="<?php echo esc_attr($settings['nft_roles'][$role_name]['minter'] ?? ''); ?>" />
                        </div>
                        <div>
                            <label for="nft_role_<?php echo $role_name; ?>_token">Token</label>
                            <input type="text" id="nft_role_<?php echo $role_name; ?>_token" name="nft_roles[<?php echo $role_name; ?>][token]" value="<?php echo esc_attr($settings['nft_roles'][$role_name]['token'] ?? ''); ?>" />
                        </div>
                        <div>
                            <label for="nft_role_<?php echo $role_name; ?>_nft_id">NFT ID</label>
                            <input type="text" id="nft_role_<?php echo $role_name; ?>_nft_id" name="nft_roles[<?php echo $role_name; ?>][nft_id]" value="<?php echo esc_attr($settings['nft_roles'][$role_name]['nft_id'] ?? ''); ?>" />
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <p>
                <button type="button" id="fungate_save_btn" class="button-primary">Save Changes</button>
            </p>
        </form>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#fungate_save_btn').on('click', function() {
            var data = {
                'action': 'save_fungate_roles',
                'data': $('#fungate_roles_form').serialize()
            };
            $.post(ajaxurl, data, function(response) {
                alert('Settings saved');
            });
        });
        $('#selected_role').on('change', function() {
            var selectedRole = $(this).val();
            $('.fungate-role-inputs').hide();
            $('.fungate-role-inputs[data-role="' + selectedRole + '"]').show();
        });

    });
    </script>
    <?php
}

// AJAX handler function
add_action('wp_ajax_save_fungate_roles', 'save_fungate_roles_ajax');
function save_fungate_roles_ajax() {
    // Check if the user has permission to save settings
    if (!current_user_can('manage_options')) {
        wp_send_json_error('You do not have permission to perform this action.');
    }

    parse_str($_POST['data'], $settings);

    // Save the settings
    update_option('fungate_nft_roles_settings', $settings);

    // Send a success message
    wp_send_json_success('Settings saved.');
}
