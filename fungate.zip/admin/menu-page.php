<?php

function fungate_menu_page(){
    fungate_admin_page_render();
    ?>
    <div class="fungate-wrap">
        <h1>Welcome to Fungate!</h1>
        <p>Thank you for using Fungate! This plugin helps you enable Web3 Login and display NFT gated content on your website.</p>
        <p>For more information and updates, please visit:</p>
        <ul>
            <li><a href="https://discord.gg/pjRuMTtDZb" target="_blank">Discord Community</a></li>
            <li><a href="https://fungate.io" target="_blank">fungate.io Website</a></li>
            <li><a href="https://github.com/stepwn/Fungate" target="_blank">GitHub Repository</a></li>
        </ul>
        
        <h2>Plugin Pages</h2>
        <p>You can configure settings using the following buttons:</p>
        <div class="fungate-plugin-buttons">
            <a class="button-primary" href="<?php echo admin_url('edit.php?post_type=fungate_nft'); ?>">Manage Posts</a>
            <a class="button-primary" href="<?php echo admin_url('admin.php?page=fungate-media'); ?>">Manage Protected Media</a>
            <a class="button-primary" href="<?php echo admin_url('admin.php?page=fungate-settings'); ?>">Configure Settings</a>
        </div>
        <br>
        <hr>
        <h1>Shortcode Usage</h1>
        <div class="fungate-shortcode-info">
            <h2>Fungate Shortcode: [fungate][/fungate]</h2>
            <p>The <code>[fungate][/fungate]</code> shortcode allows you to show content only to specific NFT owners.</p>
            <p>If any of the provided attributes match the attributes of a user's owned Loopring NFTs, the content inside the shortcode will be displayed. Otherwise, the content will not be served.</p>
            
            <div class="fungate-shortcode-example">
                <h3>Usage:</h3>
                <pre><code>[fungate nft="0xabc123" minter="0xabc123" contract="0xabc123"]Your content here[/fungate]</code></pre>
                * Only one of the nft, minter, or contract attributes needs to be set to work. If multiple are set it will only allow access if all the conditions are true.
                <pre><code>[fungate nft="0xabc123"]Your content here[/fungate]</code></pre>
            </div>
        </div>
        <div class="fungate-shortcode-info">
        <h2>Fungate Media Shortcode: [fungate_media]</h2>
            <p>The <code>[fungate_media]</code> shortcode allows you to selectively embed/stream protected media (.mp4, .mp3, .jpg, etc).</p>
            <p>First, upload your protected media file <a class="button-primary" href="<?php echo admin_url('admin.php?page=fungate-media'); ?>">Manage Protected Media</a></p>
        
            <div class="fungate-shortcode-example">
                <h3>Usage:</h3>
                <pre><code>[fungate_media type="video" src="https://yoursite.com/wp-content/plugins/Fungate/protected-content/your-file.mp4"]</code></pre>
                * Copy the full link to the protected file into the <code>src=""</code> attribute.<br>
                * Use the <code>type=""</code> attribute to your media type: image, video, or audio.
                <p>Fungate will stream the embedded media</p>
            </div>
        </div>
        <div class="fungate-shortcode-info">
        <h2>Fungate Media Download Shortcode: [fungate_media_download]</h2>
            <p>The <code>[fungate_media_download]</code> shortcode allows you to selectively serve protected media (.mp4, .zip, .webm, .obj, etc).</p>
            <p>First, upload your protected media file <a class="button-primary" href="<?php echo admin_url('admin.php?page=fungate-media'); ?>">Manage Protected Media</a></p>
        
            <div class="fungate-shortcode-example">
                <h3>Usage:</h3>
                <pre><code>[fungate_media_download src="https://yoursite.com/wp-content/plugins/Fungate/protected-content/your-file.zip"]</code></pre>
                * Copy the full link to the protected file into the <code>src=""</code> attribute.<br>
                * Use the <code>text="Download Button Text"</code> attribute to change the download button text.
                <p>Fungate will display a download button to serve the protected media file</p>
            </div>
        </div>
    </div>
    <?php
}