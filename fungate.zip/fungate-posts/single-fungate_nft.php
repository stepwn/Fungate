<?php

if ( wp_is_block_theme() ) {
    block_header_area();
}


while ( have_posts() ) : the_post();
?>
<div class="fungate-wrapper">
    <?php if ( get_post_meta( get_the_ID(), 'fungate_layout_style', true ) === 'two-column' ) : ?>
    <div class="fungate-two-column-layout">
        <div class="fungate-left-column">
            <h1 class="fungate-nft-title"><?php the_title(); ?></h1>
            <?php the_post_thumbnail( 'large' ); ?>
            <p><?php echo esc_attr(get_post_meta( get_the_ID(), 'fungate_short_description', true )); ?></p>
        </div>
        <div class="fungate-right-column">
            <?php the_content(); ?>
        </div>
    </div>
    <?php else : ?>
    <div class="fungate-stacked-layout">
        <h1 class="fungate-nft-title"><?php the_title(); ?></h1>
        <?php the_post_thumbnail( 'large' ); ?>
        <p><?php echo esc_attr(get_post_meta( get_the_ID(), 'fungate_short_description', true )); ?></p>
        <?php the_content(); ?>
    </div>
    <?php endif; ?>
</div>
<?php
endwhile;

if ( wp_is_block_theme() ) {
    block_footer_area();
}
?>
