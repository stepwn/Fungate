<?php
/**
 * Registers a custom post type for Fungate NFTs.
 */
function fungate_nft_custom_post_type() {
    register_post_type('fungate_nft', array(
        'labels' => array(
            'name' => __('Fungate NFTs', 'fungate'),
            'singular_name' => __('Fungate NFT', 'fungate'),
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-images-alt2', // Custom menu icon
        'rewrite' => array('slug' => 'fungate-nfts'), // Custom permalink structure
        'taxonomies' => array('category'), // Adding taxonomies
        'has_archive' => true, // Enabling archive page
        'show_in_menu' => false, // Hiding from menu
    ));
}

add_action('init', 'fungate_nft_custom_post_type');

/**
 * Overrides the default template for the 'fungate_nft' custom post type.
 *
 * @param string $template The path of the template to include.
 * @return string The modified template path.
 */
function fungate_custom_post_template($template) {
    if (is_singular('fungate_nft')) {
        add_action('wp_enqueue_scripts', function() {
            $style_path = plugin_dir_url(__FILE__) . 'css/fungate-post-style.css';
            wp_enqueue_style('fungate-post-style', $style_path);
        });
        include_once('walletconnect.php');
        ob_start();
        include(plugin_dir_path(__FILE__) . 'single-fungate_nft.php');
        $content = ob_get_clean();
        wp_head();
        echo wp_kses_post($content);
        wp_footer();
        return '';
    }
    return $template;
}

add_filter('template_include', 'fungate_custom_post_template');

/**
 * Adds a meta box for selecting layout style in Fungate NFT custom post type.
 */
function fungate_add_layout_style_meta_box() {
    add_meta_box(
        'fungate_layout_style_meta_box',
        __('Layout Style', 'fungate'),
        'fungate_render_layout_style_meta_box',
        'fungate_nft',
        'normal',
        'default'
    );
}

add_action('add_meta_boxes', 'fungate_add_layout_style_meta_box');

/**
 * Renders the content of the layout style meta box.
 *
 * @param WP_Post $post The current post object.
 */
function fungate_render_layout_style_meta_box($post) {
    $layout_style = get_post_meta($post->ID, 'fungate_layout_style', true);
    $layout_options = array(
        'two-column' => __('Two-Column', 'fungate'),
        'stacked' => __('Stacked', 'fungate'),
    );

    foreach ($layout_options as $value => $label) {
        echo '<label>';
        echo '<input type="radio" name="fungate_layout_style" value="' . esc_attr($value) . '" ' . checked($layout_style, $value, false) . '>';
        echo ' ' . esc_html($label);
        echo '</label><br>';
    }
}

/**
 * Saves the selected layout style when the post is saved or updated.
 *
 * @param int $post_id The ID of the current post.
 */
function fungate_save_layout_style_meta_box($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['fungate_layout_style'])) {
        $layout_style = sanitize_key($_POST['fungate_layout_style']);
        update_post_meta($post_id, 'fungate_layout_style', $layout_style);
    }
}

add_action('save_post', 'fungate_save_layout_style_meta_box');

/**
 * Adds custom meta fields to the Fungate NFT custom post type.
 */
function fungate_nft_meta_fields() {
    add_meta_box(
        'fungate_nft_meta',
        __('Fungate NFT Details', 'fungate'),
        'fungate_nft_meta_callback',
        'fungate_nft',
        'normal',
        'default'
    );
}

add_action('add_meta_boxes', 'fungate_nft_meta_fields');

/**
 * Callback function for rendering meta box content.
 *
 * @param WP_Post $post The current post object.
 */
function fungate_nft_meta_callback($post) {
    wp_nonce_field('fungate_nft_nonce', 'fungate_nft_nonce');
    // Fetch existing meta values
    $meta_fields = array(
        'fungate_nft_id' => __('Fungate NFT ID', 'fungate'),
        'fungate_minter' => __('Fungate Minter', 'fungate'),
        'fungate_token' => __('Fungate Token', 'fungate'),
        'fungate_contract' => __('Fungate Contract', 'fungate'),
        'fungate_short_description' => __('Fungate Short Description', 'fungate')
    );

    foreach ($meta_fields as $meta_key => $label) {
        $value = get_post_meta($post->ID, $meta_key, true);
        echo '<label for="' . esc_attr($meta_key) . '">' . esc_html($label) . ':</label>';
        echo '<input type="text" id="' . esc_attr($meta_key) . '" name="' . esc_attr($meta_key) . '" value="' . esc_attr($value) . '"><br>';
    }
}

/**
 * Saves custom meta fields for the Fungate NFT custom post type.
 *
 * @param int $post_id The ID of the current post.
 */
function fungate_save_fungate_nft_meta($post_id) {
    if (!isset($_POST['fungate_nft_nonce']) || !wp_verify_nonce(sanitize_text_field( wp_unslash ($_POST['fungate_nft_nonce'])), 'fungate_nft_nonce') || !current_user_can('edit_post', $post_id)) {
        return;
    }

    $meta_fields = array('fungate_nft_id', 'fungate_minter', 'fungate_token', 'fungate_contract', 'fungate_short_description');
    foreach ($meta_fields as $meta_key) {
        if (isset($_POST[$meta_key])) {
            update_post_meta($post_id, $meta_key, sanitize_text_field($_POST[$meta_key]));
        }
    }
}

add_action('save_post_fungate_nft', 'fungate_save_fungate_nft_meta');

/**
 * Adds the Fungate shortcode to posts automatically based on their metadata.
 *
 * @param string $content The post content.
 * @return string Modified post content.
 */
function fungate_add_shortcode_to_posts($content) {
    global $post;

    if ('fungate_nft' !== get_post_type($post)) {
        return $content;
    }

    // Extract metadata values
    $nft_id_metadata = get_post_meta($post->ID, 'fungate_nft_id', true);
    $minter_metadata = get_post_meta($post->ID, 'fungate_minter', true);
    $token_metadata = get_post_meta($post->ID, 'fungate_token', true);
    $contract_metadata = get_post_meta($post->ID, 'fungate_contract', true);

    if ($nft_id_metadata || $minter_metadata || $token_metadata || $contract_metadata) {
        // Construct the shortcode
        $shortcode = sprintf(
            '[fungate nft_id="%s" minter="%s" token="%s" contract="%s"]%s[/fungate]',
            esc_attr($nft_id_metadata),
            esc_attr($minter_metadata),
            esc_attr($token_metadata),
            esc_attr($contract_metadata),
            $content
        );
        return $shortcode;
    }

    return $content;
}

add_filter('the_content', 'fungate_add_shortcode_to_posts');
