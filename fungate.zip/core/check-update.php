<?php
// check-update.php

// Function to check for plugin updates
function fungate_check_for_update() {
    $current_version = '1.2.0'; // Replace with your current plugin version
    $update_check_transient = 'fungate_update_check';
    $update_check_url = 'https://fungate.io/wp-content/plugins/fungate/core/license/check-update-endpoint.php';

    // Check if the transient is set and not expired
    if (false === ($latest_version = get_transient($update_check_transient))) {
        error_log('checking for update');
        // Create a hashed version of the site URL
        $hashed_site_url = hash('sha256', site_url());

        // Initialize cURL session
        $curl = curl_init();

        // Set cURL options
        curl_setopt_array($curl, array(
            CURLOPT_URL => $update_check_url . '?site_hash=' . $hashed_site_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true
        ));

        // Execute the cURL session
        $response = curl_exec($curl);

        // Check for errors in the cURL session
        if ($response === false) {
            error_log('cURL Error: ' . curl_error($curl));
            curl_close($curl);
            return;
        }

        // Close the cURL session
        curl_close($curl);

        // Retrieve the latest version from the response
        $latest_version = trim($response); // Trimming to ensure no extra whitespace
        // Set the transient for a certain period, e.g., 12 hours
        set_transient($update_check_transient, $latest_version, 12 * HOUR_IN_SECONDS);
    }

    // Compare versions and add update message if necessary
    if (version_compare($current_version, $latest_version, '<')) {
        add_action('admin_notices', 'fungate_update_notice');
    }
}

function fungate_update_notice() {
    ?>
    <div class="notice notice-warning is-dismissible">
        <p><?php _e('There is a new version of Fungate available. <a href="https://fungate.io">Please update now.</a>', 'text-domain'); ?></p>
    </div>
    <?php
}

add_action('admin_init', 'fungate_check_for_update');
