<?php
// Function to create the protected-folder and .htaccess file
function fungate_create_protected_folder() {
    $protected_folder_path = plugin_dir_path(__FILE__) . 'protected-folder/';
    $htaccess_content = "# Deny all access from outside\n"
                    ."Order deny,allow\n"
                    ."Deny from all\n";

    if (!file_exists($protected_folder_path)) {
        // Create the protected folder
        mkdir($protected_folder_path, 0755, true);

        // Create and write the .htaccess file
        $htaccess_file_path = $protected_folder_path . '.htaccess';
        file_put_contents($htaccess_file_path, $htaccess_content);
    }
}

// Hook the function to plugin activation
register_activation_hook(__FILE__, 'fungate_create_protected_folder');

add_action( 'after_setup_theme', 'ccwp_disable_admin_bar_for_certain_role' );

function ccwp_disable_admin_bar_for_certain_role() {
    // Change 'subscriber' to the role you want to target
    $role_to_disable = 'fungate_user';

    if ( is_user_logged_in() ) {
        $current_user = wp_get_current_user();
        if ( in_array( $role_to_disable, $current_user->roles ) ) {
            // Disable the top toolbar
            add_filter('show_admin_bar', '__return_false');
        }
    }
}
