<?php
/**
 * Registers REST API routes for the Fungate plugin.
 */
function fungate_register_rest_routes() {
    register_rest_route('fungate/v1', '/logout', array(
        'methods' => 'GET',
        'callback' => 'fungate_handle_logout',
        'permission_callback' => function () {
            return is_user_logged_in();
        }
    ));
}

add_action('rest_api_init', 'fungate_register_rest_routes');

/**
 * Handles the user logout action.
 *
 * @return WP_REST_Response
 */
function fungate_handle_logout() {
    if (is_user_logged_in()) {
        wp_logout();
        return new WP_REST_Response('Successfully logged out', 200);
    }

    return new WP_REST_Response('User not logged in', 401);
}
