<?php
/**
 * Embeds protected media using a shortcode.
 *
 * @param array $atts Shortcode attributes.
 * @return string HTML output for the embedded media.
 */
function fungate_embed_protected_media($atts) {
    $atts = shortcode_atts(array(
        'src' => '',
        'text' => 'Download' // Default text is "Download"
    ), $atts);

    $file_url = esc_url($atts['src']);
    $button_text = esc_attr($atts['text']);

    $nonce = wp_create_nonce('fungate_download_' . basename($file_url));

    return "<a class='fungate-download-button' href='" . esc_url(admin_url('admin-ajax.php?action=fungate_serve_protected_file&file=' . urlencode($file_url) . '&nonce=' . $nonce)) . "' download><button class='wp-block-button__link wp-element-button'>$button_text</button></a>";
}
add_shortcode('fungate_media_download', 'fungate_embed_protected_media');

/**
 * Serves protected file for download.
 */
function fungate_serve_protected_file() {
    $file_url = isset($_GET['file']) ? sanitize_text_field($_GET['file']) : '';
    $nonce = isset($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : '';

    if (!wp_verify_nonce($nonce, 'fungate_download_' . basename($file_url))) {
        wp_die('Unauthorized access', 'Error', array('response' => 403));
    }

    $protected_folder_path = plugin_dir_path(dirname(__FILE__)) . 'protected-folder/';
    $file_path = $protected_folder_path . basename($file_url);

    if (!file_exists($file_path)) {
        wp_die('File not found', 'Error', array('response' => 404));
    }

    $mime_type = mime_content_type($file_path);
    header('Content-Type: ' . $mime_type);
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    readfile($file_path);
    exit;
}
add_action('wp_ajax_fungate_serve_protected_file', 'fungate_serve_protected_file');
add_action('wp_ajax_nopriv_fungate_serve_protected_file', 'fungate_serve_protected_file');

/**
 * Embeds media into posts via a shortcode.
 *
 * @param array $atts Shortcode attributes.
 * @return string HTML output for the embedded media.
 */
function fungate_stream_media_shortcode($atts) {
    $atts = shortcode_atts(array(
        'type' => 'image',
        'src' => ''
    ), $atts);

    $file_url = esc_url($atts['src']);
    $nonce = wp_create_nonce('fungate_stream_' . basename($file_url));
    $output = '';

    switch ($atts['type']) {
        case 'video':
            $output = '<video controls width="100%"><source src="' . esc_url(admin_url('admin-ajax.php?action=fungate_stream_protected_media&file=' . urlencode($file_url) . '&nonce=' . $nonce)) . '" type="video/mp4">Your browser does not support the video tag.</video>';
            break;
        case 'audio':
            $output = '<audio controls><source src="' . esc_url(admin_url('admin-ajax.php?action=fungate_stream_protected_media&file=' . urlencode($file_url) . '&nonce=' . $nonce)) . '" type="audio/mp3">Your browser does not support the audio element.</audio>';
            break;
        case 'image':
            $output = '<img src="' . esc_url(admin_url('admin-ajax.php?action=fungate_stream_protected_media&file=' . urlencode($file_url) . '&nonce=' . $nonce)) . '" alt="Protected Image" width="100%">';
            break;
    }

    return $output;
}
add_shortcode('fungate_media', 'fungate_stream_media_shortcode');

