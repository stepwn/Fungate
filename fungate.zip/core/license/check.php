<?php
require_once('/home/fungate/public_html/wp-load.php');

function check_license($license_key) {
    global $wpdb;

    $table_name = $wpdb->prefix . 'fungate_licenses';
    $license_key = sanitize_text_field($license_key);

    // Query the database for the license key
    $license = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE license_key = %s", $license_key));

    if ($license) {
        // Check if the license is active and is a 'chainhopper' license
        if ($license->status === 'active' && $license->product_id === 'chainhopper') {
            // Generate a nonce for downloading the chainhopper version
            $nonce = wp_create_nonce('fungate_chainhopper_download_nonce');

            return ['success' => true, 'status' => 'chainhopper', 'nonce' => $nonce];
        } else {
            return ['success' => false, 'error' => 'License is not active'];
        }
    } else {
        return ['success' => false, 'error' => 'License not found'];
    }
}

// Handle the request
if (isset($_POST['license_key'])) {
    $license_key = $_POST['license_key'];
    $result = check_license($license_key);

    // Return the result as JSON
    echo json_encode($result);
} else {
    echo json_encode(['success' => false, 'error' => 'No license key provided']);
}
