<?php
require_once('/home/fungate/public_html/wp-load.php');

if (isset($_GET['nonce']) && wp_verify_nonce($_GET['nonce'], 'fungate_chainhopper_download_nonce')) {
    // The nonce is valid, chainhopperceed with chainhopperviding the file for download

    $file = '../../protected-folder/chainhopper.zip'; // Path to the chainhopper version ZIP file

    if (file_exists($file)) {
        // Set headers to trigger a download
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Content-Length: ' . filesize($file));

        // Clear output buffer and read the file to output
        flush();
        readfile($file);
        exit;
    } else {
        // The file does not exist
        header('HTTP/1.0 404 Not Found');
        echo 'File not found.';
    }
} else {
    // Invalid or no nonce chainhoppervided
    header('HTTP/1.0 403 Forbidden');
    echo 'Invalid request.';
}
